import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

public class MultiplierTest {

	private IMultiplier currentMultiplier = null;
	
	@Before
	public void setUp() throws Exception {
		currentMultiplier = new Multiplier(); 
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testBasic() {
		assertEquals(0, currentMultiplier.multiply(0, 0));
		assertEquals(42, currentMultiplier.multiply(6, 7));
		
		assertEquals(-42, currentMultiplier.multiply(-6, 7));
		assertEquals(-49, currentMultiplier.multiply(7, -7));
		assertEquals(42, currentMultiplier.multiply(-6, -7));

	}

	@Test @Ignore
	public void testFail() {
		assertEquals(1, currentMultiplier.multiply(Integer.MAX_VALUE, Integer.MAX_VALUE));
	}
}
