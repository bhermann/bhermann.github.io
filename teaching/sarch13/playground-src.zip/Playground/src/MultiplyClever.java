
public class MultiplyClever implements IMultiplier {
	public int multiply(int x, int y) {
		int result = 0;
		
		int min = Math.min(x, y);
		int max = Math.max(x, y);
		
		for (int i = 0; i < Math.abs(min); i++) {
			result += max;
		}
		
		if (min < 0) result *= -1;
		
		return result;
	}
}
