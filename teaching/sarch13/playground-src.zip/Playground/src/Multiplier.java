
public class Multiplier implements IMultiplier {

	/* (non-Javadoc)
	 * @see IMultiplier#multiply(int, int)
	 */
	@Override
	public int multiply(int x, int y) {
		assert(x >= 0);
		assert(y >= 0);
		
		return x * y;
	}
	

	

	
	
}
