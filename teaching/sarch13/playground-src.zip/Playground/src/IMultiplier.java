public interface IMultiplier {

	public abstract int multiply(int x, int y);

}