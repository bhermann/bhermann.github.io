
public class MultiplyInteratively implements IMultiplier {
	public int multiply (int x, int y) {
		int result = 0;
		for (int i = 0; i < Math.abs(y) ; i++) {
			result += x;
		}
		
		if (y < 0) result *= -1;
		
		return result;
	}
}
